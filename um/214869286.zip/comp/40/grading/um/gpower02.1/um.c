/* um.c 
    Written by Georgia Power and Brooke Thompson for CS40 HW6: UM 

        
        Program driver for UM program. 
        
        Reads in program words and advances the execution of instructions and
        defines the Universal_Machine struct type. Instantiates a 
        UM_memory_structures struct to serve as the memory for the UM and
        implements the load_program UM instruction. 

*/
#include <stdint.h>
#include <stdio.h>
#include <assert.h>
#include <seq.h>
#include <string.h>
#include <stdlib.h>
#include <stack.h>
#include <bitpack.h>
#include <sys/stat.h>
#include <uarray.h>

#include "ummem.h"
#include "umarithmetic.h"


typedef uint32_t UM_register; 
typedef uint32_t OPCODE;
typedef uint32_t Program_P;
typedef UArray_T Segment;
#define CHARSINWORD 4
#define OPCODE_WIDTH 4
#define OPCODE_LSB 28
#define RA_LSB 6
#define RB_LSB 3
#define RC_LSB 0
#define REG_WIDTH 3
#define BYTE 8
#define BYTE_LSB 24



/* define integers as significant UM opcodes */
typedef enum Um_opcode {
        CMOV = 0, SLOAD, SSTORE, ADD, MUL, DIV,
        NAND, HALT, ACTIVATE, INACTIVATE, OUT, IN, LOADP, LV
} Um_opcode;




/***** struct UM_memory_structures *********/
/*  Packaged representation of UM's memory 
    member variables:   
        Seq_T holding mapped memory segments in the UM in the form of UArray_Ts
        Stack_T holding pointers to uint32_t IDs indicating segments that have 
        been unmapped.
*/
typedef struct UM_memory_structures { 
        Seq_T mapped_memory; 
        Stack_T unmapped_IDs;
} *UM_mem;



/***** struct Universal_Machine *********/
/* 
    Packaged representation of the UM and what it owns
    member variables:
         8 - index array of uint32_ts typedef'd as UM_register
            - serves as the UM's registers
         Program_counter - uint32_t counter typedef'd as Program_P
            - keeps track of UM_instruction being executed at any given point
*/
typedef struct Universal_Machine { 
        UM_register registers[8];
        Program_P program_counter;
} *UM;


/* function declarations */
UArray_T IO_in(int filelength, FILE *input); 
void make_segment0(UM_mem memory, int filelength, FILE* program);
int filelength(char *argv[]); 
UM constructUM();
void load_program(UM ourUM, UM_mem memory, UM_register rb, UM_register rc);
void free_UM (UM ourUM);
UM_instruction get4bytes(FILE* input);
void machine_cycle (UM_mem memory, UM ourUM);
UM_register getReg(UM_instruction current, uint32_t LSB);



int main(int argc, char *argv[]) 
{ 
    
        if (argc != 2) {
        
                fprintf(stderr, "Usage: ./um [filename]\n");
                exit(EXIT_FAILURE);

        }
    
        int filebytes = filelength(argv);
        FILE* program = fopen(argv[1], "r");
    
        if (program == NULL) { 
                fprintf(stderr, "Please enter valid file.\n");
                exit(EXIT_FAILURE);
        }


        /* allocate memory and load program's words from input*/
        UM_mem memory = constructMemory();
        make_segment0(memory, filebytes, program);
        UM ourUM = constructUM(memory);

        /* execute machine instructions in the zero segment*/
        machine_cycle (memory, ourUM);

        /* free allocated memory */
        fclose(program);
        freeUM_mem(memory);
        free_UM (ourUM);

    
}


/********** constructUM ********
 *
 *  Allocates memory for a UM struct, initializes its registers to 0, and 
 *  sets its program counter to 0.
 * 
 * Inputs: none
 *     
 * Return: a UM struct pointer holding the UM's registers and program counter
 *      
 * Notes: will CRE if malloc fails
 *        memory allocated here is freed by free_UM at the end of the driver 
 *          main
 *      
 ************************/
UM constructUM() 
{
   
        UM myum = malloc(sizeof(struct Universal_Machine));
        assert (myum != NULL);
        
        /* initialize all registers to 0 */
        for (int reg = 0; reg < 8; reg++) { 
                myum->registers[reg] = 0;
        }
    
        /* set program counter to 0 */
        myum->program_counter = 0;

        return myum;
}


/****** filelength *******
 * 
 *  Uses stat library functions to find the length of a given file 
 * 
 *  Inputs: char array representing the command line arguments
 *     
 *  Return: integer representing the length of a given .um file
 *  Expects: none 
 *           
 ************************/
int filelength(char *argv[]) 
{ 
        struct stat info;
        stat(argv[1], &info);
        int filelength = info.st_size;

        return filelength;
}


/********** make_segment0 ********
 *
 *  Calls helper function IO_in that makes a segment from words in a given file.
 *   Places this segment in the member Seq_T of the passed UM memory struct 
 *  representing mapped_memory. 
 *
 *  
 * 
 * Inputs: UM memory struct pointer: holds structures where $m[0] will be 
 *              stored int representing length of file from which we are 
 *              reading FILE* representing the input file 
 *     
 * Return:  none
 * Expects: UM_mem and FILE* not to be NULL
 *      
 * Notes: will CRE if expectations are not met. 
 *      
 ************************/
void make_segment0(UM_mem memory, int filelength, FILE* program) 
{
     
        assert (program != NULL);
        assert (memory != NULL);

        /* read in from input and put in 0 segment */
        UArray_T segment_0 = IO_in(filelength, program);
        assert (segment_0 != NULL);

        /* add zero segment to sequence holding segments */
        Seq_addlo(memory->mapped_memory, segment_0);

}


/********** make_segment0 ********
 *
 *   Makes a UArray_T segment holding words in a given file and returns to 
 *  caller.
 *  
 * Inputs: 
 *          int representing length of file from which we are reading
 *          FILE* representing the input file 
 *     
 * Return:  UArray_T representing a memory segment 
 * Expects: FILE* not to be NULL
 *      
 * Notes: will CRE if expectations are not met, if allocated segment is NULL, 
 *        or accessed pointer in allocated segment is NULL. 
 *        Memory allocated here will be freed by free_UM at the end of the 
 *        program or when the load_program instruction replaces the UM's 
 *        0 segment. 
 *      
 ************************/
UArray_T IO_in(int filelength, FILE *input) 
{ 
        assert (input != NULL);

        /* each spot in a segment can hold 4 characters */
        int segment_length = filelength / CHARSINWORD;

        UArray_T new_segment = UArray_new(segment_length, sizeof(uint32_t));
        assert (new_segment != NULL);
    
        /* read input from file  */
        for (int i = 0; i < segment_length; i++) { 
        
                uint64_t word = get4bytes(input);

                /* place word into segment */
                assert(UArray_at(new_segment, i) != NULL);
                *(UM_instruction*)UArray_at(new_segment, i) = 
                                                (uint32_t)(uintptr_t)word;
        
        }
    
    return new_segment;    
}




/********** load_program ********
 *
 *  Copies a segment at an index in memory denoted by the value in register c
 *  and loads it in the zero segment as the program being executed. 
 *  Sets program pointer to the index $m[rb].
 *  
 * Inputs: 
 *          UM struct pointer holding UM regsiters and program pointer
 *          UM memory struct pointer holding mapped memory to be accessed
 *          UM registers ra, rb and rc
 *     
 * Return:  none 
 * Expects: Passed struct pointers not to be NULL
 *      
 * Notes: will CRE if expectations are not met. Frees UArray_T holding the
 *          previous zero segment. Will CRE if UArray_new fails, if accessed
 *          spot in the segment being copied to or the segmet being copies from 
 *          is NULL, or if current zero segment is NULL.
 *      
 ************************/
void load_program(UM ourUM, UM_mem memory, UM_register rb, UM_register rc) 
{
    
        assert (memory != NULL);
        assert (ourUM != NULL);
    
        /* zero case: 0 segment does not need to be duplicated */
        if (ourUM->registers[rb] == 0) { 
                ourUM->program_counter = ourUM->registers[rc];
                return;
        }
    
        else {
                /* get segment to be copied */
                UArray_T to_dup = Seq_get(memory->mapped_memory, 
                                                        ourUM->registers[rb]);
                int new_length = UArray_length(to_dup);
                /* make segment to be copied into */
                UArray_T copy = UArray_new(new_length, sizeof(uint32_t));
                assert (copy != NULL);
        
                /* copy */
                for (int index = 0; index < new_length; index++) { 
            
                        assert(UArray_at(copy, index) != NULL);
                        assert(UArray_at(to_dup, index) != NULL);
            
                         *(UM_instruction*)UArray_at(copy, index) = 
                                *(UM_instruction*)UArray_at(to_dup, index);
                }       

                /* get and free current seg0, put copied segment in as seg0 */
                UArray_T curr_segment0 = Seq_get(memory->mapped_memory, 0);
                assert (curr_segment0 != NULL);
                UArray_free(&curr_segment0);

                UArray_T garb = Seq_put(memory->mapped_memory, 0, copy);
                (void)garb;
                
                ourUM->program_counter = ourUM->registers[rc];
        
        }    

}


/********** free_UM ********
 *
 *  Deallocates memory allocated for the UM struct pointer
 *  
 * Inputs: 
 *          UM struct pointer 
 *     
 * Return:  none 
 * Expects: Passed struct pointer not to be NULL
 *      
 * Notes: will CRE if expectations are not met. 
 *      
 ************************/
void free_UM (UM ourUM)
{
        assert(ourUM != NULL);
        free (ourUM);
}


/********** get4bytes ********
 *
 *  Gets a 32 bit word from an input file and returns it as a UM_instruction
 *  
 * Inputs: 
 *          FILE* representing the input from which we are reading 
 *     
 * Return:  uint32_t UM_instruction holding a UM instruction 
 * Expects: Passed FILE* not to be NULL
 *      
 * Notes: will CRE if expectations are not met. 
 *      
 ************************/
UM_instruction get4bytes (FILE* input)
{
        assert (input != NULL);
    
        /* make 32 bit word out of 4 characters */
        unsigned lsb = 24;
        uint64_t word = 0;

        for (int j = 0; j < CHARSINWORD; j++) {
                int value = fgetc(input);
                word = Bitpack_newu(word, BYTE, lsb, (uint64_t)value);
                lsb = lsb - BYTE;
        }

        return word;

}


/********** machine_cycle ********
 *
 *  Query loop that iterates over the zero segment, calling functions 
 *  that execute each UM_instuction 
 *  
 * Inputs: 
 *          UM struct pointer holding registers and program counter 
 *          UM memory pointer holding mapped memory, unmapped IDs
 *     
 * Return:  none 
 * Expects: Passed struct pointers not to be NULL
 *      
 * Notes: will CRE if expectations are not met. 
 *      
 ************************/
void machine_cycle (UM_mem memory, UM ourUM)
{
        assert (memory != NULL);
        assert (ourUM != NULL);
        assert (memory->mapped_memory != NULL);
        
        Um_opcode op = 0;
        /* get zero segment */
        Segment ZeroSeg = Seq_get(memory->mapped_memory, 0);
        assert(ZeroSeg != NULL);
    
        while (op != HALT) {
    
                /* get the instruction we are currently executing */
                UM_instruction *current = 
                        ((UM_instruction *)UArray_at(ZeroSeg, 
                                                ourUM->program_counter));
                assert (current != NULL);
                UM_instruction curr = *current;

                /* get the instruction we are currently executing */
                op = (uint32_t)Bitpack_getu((uint64_t)curr, OPCODE_WIDTH, 
                                                                OPCODE_LSB);
                ourUM->program_counter++;
        
                /* if op != loadval, get three registers*/
                if (op == LV) { 
                        load_value(curr, ourUM->registers);

                } else {
            
                        UM_register ra = getReg (curr, RA_LSB);
                        UM_register rb = getReg (curr, RB_LSB);
                        UM_register rc = getReg (curr, RC_LSB);

                        if (op == CMOV) { 
                                conditional_move(ourUM->registers, ra, rb, rc);
                        }

                        if (op == SLOAD){ 
                                seg_load(ourUM->registers, memory, ra, rb, rc);
                        }

                        if (op == SSTORE) { 
                                seg_store(ourUM->registers, memory, ra, rb, rc);
                        }

                        if (op == ADD) { 
                                add(ourUM->registers, ra, rb, rc);
                        }

                        if (op == MUL) { 
                                multiply(ourUM->registers, ra, rb, rc);
                        }

                        if (op == DIV) {
                                divide(ourUM->registers, ra, rb, rc);
                        }

                        if (op == NAND) { 
                                bitwiseNAND(ourUM->registers, ra, rb, rc);
                        }

                        if (op == ACTIVATE) { 
                                map_seg(ourUM->registers, memory, rc, rb);
                        }

                        if (op == INACTIVATE) { 
                                unmap_seg(ourUM->registers, memory, rc);
                        }

                        if (op == OUT) { 
                                output_val(ourUM->registers, rc);
                        }

                        if (op == IN) { 
                                input(ourUM->registers, rc, stdin);
                        }

                        if (op == LOADP) { 
                                load_program(ourUM, memory, rb, rc);
                                /* set segment this loop runs on to the new 
                                                        loaded program */
                                ZeroSeg = Seq_get(memory->mapped_memory,0);
                                assert(ZeroSeg != NULL);

                        }
                }
         
        }  
             
}




/********** getReg ********
 *
 *  Extracts a UM register number from given instruction and LSB. 
 *  
 * Inputs: 
 *          UM_instruction, a uint32_t from which to extract values
 *          uint32_t LSB, which indicates which register we are extracting 
 *          (ra, rb, rc);
 *     
 * Return:  UM_register, a uint32_t
 *      
 ************************/
UM_register getReg (UM_instruction current, uint32_t LSB)
{
        return (uint32_t)Bitpack_getu((uint64_t)current, REG_WIDTH, LSB);

}


