/* umarithmetic.c 
    Written by Georgia Power and Brooke Thompson for CS40 HW6: UM 

    
        Interface for the umarithmetic module. Defines load value, add,
        multiply, divide, conditional move, input, output, and bitwise NAND 
        used by the UM program. The UM driver uses these functions to execute 
        corresponding UM instructions. 

    
*/

#ifndef UM_ARITHMETIC
#define UM_ARITHMETIC


#define UM_register uint32_t
#define UM_instruction uint32_t

void load_value(UM_instruction instruction, UM_register *registers);
void add(UM_register *registers, UM_register ra, UM_register rb,
                                                            UM_register rc);
void multiply(UM_register *registers, UM_register ra, UM_register rb, 
                                                            UM_register rc);
void divide(UM_register *registers, UM_register ra, UM_register rb, 
                                                        UM_register rc);
void conditional_move(UM_register *registers, UM_register ra, UM_register 
                                                        rb, UM_register rc);
void input(UM_register *registers, UM_register rc, FILE*input);
void output_val(UM_register *registers, UM_register rc);
void bitwiseNAND(UM_register *registers, UM_register ra, UM_register 
                                                    rb, UM_register rc);

#endif