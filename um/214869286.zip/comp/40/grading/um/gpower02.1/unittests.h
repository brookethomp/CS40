#include <stdint.h>
#include <stdio.h>
#include <assert.h>
#include <seq.h>
#include <string.h>
#include <stdlib.h>
#include <stack.h>
#include <bitpack.h>
#include <sys/stat.h>
#include <uarray.h>
#include "ummem.h"



typedef uint32_t UM_register; 
typedef uint32_t Program_P;
#define charsinword 4



typedef struct UM_memory_structures { 
    Seq_T mapped_memory; 
    Stack_T unmapped_IDs;
} *UM_mem;


typedef struct Universal_Machine { 
    UM_register registers[8];
    UM_mem memory;
    Program_P* program_pointer;
} *UM;




// duplicates 0 segment and puts into 
void load_program_0test(Universal_Machine* ourUM);
{
    
    
    uint32_t rc = ourUM->;
    uint32_t rb = ;

    map_seg(ourUM, rc, rb);
    load_program(ourUM, rb);
    fprintf(stderr, "register 7 %u\n", ourUM->registers[rb]);
    
    
    uint32_t rc = 3;
    uint32_t rb = 2;
    map_seg(ourUM, rc, rb);
    load_program(ourUM, rb);
    fprintf(stderr, "register 7 %u\n", ourUM->registers[rb]);
}

