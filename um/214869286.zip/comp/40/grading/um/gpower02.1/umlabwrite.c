#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "assert.h"
#include "fmt.h"
#include "seq.h"

extern void Um_write_sequence(FILE *output, Seq_T instructions);

extern void build_halt_test(Seq_T instructions);
extern void output_test(Seq_T instructions);
extern void build_threeregisters_test(Seq_T instructions);
//BASIC
extern void add_test(Seq_T instructions);
extern void load_6_test(Seq_T instructions);
extern void load_val_once_test(Seq_T instructions);
//ADD
extern void add_output(Seq_T instructions);
extern void overload_add_test(Seq_T instructions);
extern void high_add_test(Seq_T instructions);
extern void consec_arithmetic(Seq_T instructions);
//DIV
extern void divide_test(Seq_T instructions);
extern void divide_frac_test(Seq_T instructions);
extern void divide_overflow(Seq_T stream);
//MULT
extern void small_mult_test(Seq_T instructions);
extern void big_mult_test(Seq_T instructions);
extern void big2_mult_test(Seq_T instructions);
extern void samereg_mult_test(Seq_T instructions);
//NAND
extern void bitwise_test(Seq_T instructions);
//Cmov
extern void condmv_0_test(Seq_T instructions);
extern void condmv_small_test(Seq_T instructions);
extern void condmv_big_test(Seq_T instructions);
//IN
extern void input1_test(Seq_T instructions);
extern void seg0_test(Seq_T instructions);
//OUT
extern void output_0_255(Seq_T stream);
extern void no_assert(Seq_T stream);

extern void reg5_sload_test(Seq_T instructions);

extern void map_unmap(Seq_T stream);
extern void map_1000_words(Seq_T stream);
//unmap

extern void unmap1_test(Seq_T stream);

//loadp
extern void loadp_test(Seq_T instructions);
//loadval
extern void loadval_low_high_tester(Seq_T stream);
extern void mult_load(Seq_T stream);

/* The array `tests` contains all unit tests for the lab. */

static struct test_info {
        const char *name;
        const char *test_input;          /* NULL means no input needed */
        const char *expected_output;
        /* writes instructions into sequence */
        void (*build_test)(Seq_T stream);
} tests[] = {
        { "halt", NULL, "", build_halt_test },
        { "output_test", NULL, "Bad!\n", output_test },
        {"load_val_once", NULL, "\41", load_val_once_test},
        {"add_output", NULL, "\41", add_output},
        {"high_add_test", NULL, "\376", high_add_test},
        {"divide_test", NULL, "\62", divide_test},
        {"divide_frac_test", NULL, "\14", divide_frac_test},
        {"small_mult_test", NULL, "\62", small_mult_test},
        {"big_mult_test", NULL, "\334", big_mult_test},
        {"big2_mult_test", NULL, "\12", big2_mult_test},
        {"samereg_mult_test", NULL, "\31", samereg_mult_test},
        {"bitwise_test", NULL, "\1", bitwise_test}, 
        {"condmv_0_test", NULL, "\5", condmv_0_test},
        {"condmv_small_test", NULL, "\7", condmv_small_test},
        {"condmv_big_test", NULL, "\365", condmv_big_test},
        {"input1_test", "!", "\41", input1_test},
        {"seg0_test", NULL, "\4", seg0_test},
        {"reg5_sload_test", NULL, "\41", reg5_sload_test},
        {"consec_arithmetic", NULL, "\2", consec_arithmetic}, 
        {"loadval_low_high_tester", NULL, "\41", loadval_low_high_tester},
        {"mult_load", NULL, "\116", mult_load},
        {"output_0_255", NULL, "\377", output_0_255},
        {"map_unmap", NULL, "\1", map_unmap}
};
#define NTESTS (sizeof(tests)/sizeof(tests[0]))

/*
 * open file 'path' for writing, then free the pathname;
 * if anything fails, checked runtime error
 */
static FILE *open_and_free_pathname(char *path);

/*
 * if contents is NULL or empty, remove the given 'path', 
 * otherwise write 'contents' into 'path'.  Either way, free 'path'.
 */
static void write_or_remove_file(char *path, const char *contents);

static void write_test_files(struct test_info *test);


int main (int argc, char *argv[])
{
        bool failed = false;
        if (argc == 1)
                for (unsigned i = 0; i < NTESTS; i++) {
                        printf("***** Writing test '%s'.\n", tests[i].name);
                        write_test_files(&tests[i]);
                }
        else
                for (int j = 1; j < argc; j++) {
                        bool tested = false;
                        for (unsigned i = 0; i < NTESTS; i++)
                                if (!strcmp(tests[i].name, argv[j])) {
                                        tested = true;
                                        write_test_files(&tests[i]);
                                }
                        if (!tested) {
                                failed = true;
                                fprintf(stderr,
                                        "***** No test named %s *****\n",
                                        argv[j]);
                        }
                }
        return failed; /* failed nonzero == exit nonzero == failure */
}


static void write_test_files(struct test_info *test)
{
        FILE *binary = open_and_free_pathname(Fmt_string("%s.um", test->name));
        Seq_T instructions = Seq_new(0);
        test->build_test(instructions);
        Um_write_sequence(binary, instructions);
        Seq_free(&instructions);
        fclose(binary);

        write_or_remove_file(Fmt_string("%s.0", test->name),
                             test->test_input);
        write_or_remove_file(Fmt_string("%s.1", test->name),
                             test->expected_output);
}


static void write_or_remove_file(char *path, const char *contents)
{
        if (contents == NULL || *contents == '\0') {
                remove(path);
        } else {
                FILE *input = fopen(path, "wb");
                assert(input != NULL);

                fputs(contents, input);
                fclose(input);
        }
        free(path);
}


static FILE *open_and_free_pathname(char *path)
{
        FILE *fp = fopen(path, "wb");
        assert(fp != NULL);

        free(path);
        return fp;
}
