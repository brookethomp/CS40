
/*
 * umlab.c
 *
 * Functions to generate UM unit tests. Once complete, this module
 * should be augmented and then linked against umlabwrite.c to produce
 * a unit test writing program.
 *  
 * A unit test is a stream of UM instructions, represented as a Hanson
 * Seq_T of 32-bit words adhering to the UM's instruction format.  
 * 
 * Any additional functions and unit tests written for the lab go
 * here. 
 *  
 */


#include <stdint.h>
#include <stdio.h>
#include <assert.h>
#include <seq.h>
#include <bitpack.h>
#include "ummem.h"


typedef uint32_t Um_instruction;
typedef enum Um_opcode {
        CMOV = 0, SLOAD, SSTORE, ADD, MUL, DIV,
        NAND, HALT, ACTIVATE, INACTIVATE, OUT, IN, LOADP, LV
} Um_opcode;


/* Functions that return the two instruction types */

Um_instruction three_register(Um_opcode op, int ra, int rb, int rc);
Um_instruction loadval(unsigned ra, unsigned val);


/* Wrapper functions for each of the instructions */


static inline Um_instruction halt(void) 
{
        return three_register(HALT, 0, 0, 0);
}

typedef enum Um_register { r0 = 0, r1, r2, r3, r4, r5, r6, r7 } Um_register;


static inline Um_instruction add(Um_register a, Um_register b, Um_register c) 
{
        return three_register(ADD, a, b, c);
}

static inline Um_instruction div(Um_register a, Um_register b, Um_register c) 
{
        return three_register(DIV, a, b, c);
}

static inline Um_instruction mul(Um_register a, Um_register b, Um_register c) 
{
        return three_register(MUL, a, b, c);
}

static inline Um_instruction cmov(Um_register a, Um_register b, Um_register c) 
{
        return three_register(CMOV, a, b, c);
}

static inline Um_instruction nand(Um_register a, Um_register b, Um_register c) 
{
        return three_register(NAND, a, b, c);
}

static inline Um_instruction input(Um_register c) 
{
        return three_register(IN, 0, 0, c);
}

static inline Um_instruction sload(Um_register a, Um_register b, Um_register c)
{
        return three_register(SLOAD, a, b, c);
}

static inline Um_instruction sstore(Um_register a, Um_register b, Um_register c)
{
        return three_register(SSTORE, a, b, c);
}

static inline Um_instruction map(Um_register b, Um_register c) 
{
        return three_register(ACTIVATE, 0, b, c);
}

static inline Um_instruction unmap(Um_register c) 
{
        return three_register(INACTIVATE, 0, 0, c);
}

static inline Um_instruction loadp(Um_register b, Um_register c) 
{
        return three_register(LOADP, 0, b, c);
}

Um_instruction output(Um_register c) 
{
        return three_register(OUT, 0, 0, c);
}

/* Functions for working with streams */

static inline void append(Seq_T stream, Um_instruction inst)
{
        assert(sizeof(inst) <= sizeof(uintptr_t));
        Seq_addhi(stream, (void *)(uintptr_t)inst);
}

const uint32_t Um_word_width = 32;

void Um_write_sequence(FILE *output, Seq_T stream)
{
        assert(output != NULL && stream != NULL);
        int stream_length = Seq_length(stream);
        for (int i = 0; i < stream_length; i++) {
                /* what does remlo do */
                Um_instruction inst = (uintptr_t)Seq_remlo(stream);
                for (int lsb = Um_word_width - 8; lsb >= 0; lsb -= 8) {
                        fputc(Bitpack_getu(inst, 8, lsb), output);
                }
        }
      
}


/* Unit tests for the UM */

void build_halt_test(Seq_T stream)
{
        append(stream, halt());
}

/* Tests loadval and output. 
    Creates word with loadval and output 
    instructions to load a value into r1 and immediatley outputthe value of 
    that register, one value and register at a time.*/
void output_test(Seq_T stream)
{
        append(stream, loadval(r1, 'B'));
        append(stream, output(r1));
        append(stream, loadval(r1, 'a'));
        append(stream, output(r1));
        append(stream, loadval(r1, 'd'));
        append(stream, output(r1));
        append(stream, loadval(r1, '!'));
        append(stream, output(r1));
        append(stream, loadval(r1, '\n'));
        append(stream, output(r1));
        append(stream, halt());

}

/*Tests add
    Creates instruction to load values into r1, r2 (5), and r3 (10) and 
    perform add. Then outputs r1 to ensure it is expected value (15).*/
void add_output(Seq_T stream) { 
        
        append(stream, loadval(r1, 0));
        append(stream, loadval(r2, 23));
        append(stream, loadval(r3, 10));
        append(stream, add(r1, r2, r3));
        append(stream, output(r1));
        append(stream, halt());

}

//Adds 6 and 48 and then places the sum, 54 into register a and outputs 
//register a
void load_6_test(Seq_T stream) {
        
        append(stream, loadval(r1, 48));
        append(stream, loadval(r2, 6));
        append(stream, loadval(r3, 0));
        append (stream, add(r3, r1, r2));
        append(stream, output(r3));
        append(stream, halt());

}

//  generate a bitpacked UM instruction using the provided opcode and 
//  three register identifiers.
Um_instruction three_register(Um_opcode op, int ra, int rb, int rc) 
{
        
        uint32_t word = 0;
        
        uint32_t with_opcode = (uint32_t)Bitpack_newu(word, 4, 28, op);
        uint32_t with_ra = (uint32_t)Bitpack_newu(with_opcode, 3, 6, ra);
        uint32_t with_rb = (uint32_t)Bitpack_newu(with_ra, 3, 3, rb); 
        uint32_t instruction = (uint32_t)Bitpack_newu(with_rb, 3, 0, rc);

        return instruction;
}

/*    Tests loadval with high values
    Creates instruction stream to :
        load r1 with 0 and output
        load r2 with 33554431 and r3 with 1000000
        Divide r2 by r3
        output r1 to ensure it is expected output of 33*/
Um_instruction loadval(unsigned ra, unsigned val) 
{ 
        uint32_t word = 0;
        uint32_t opcode = LV;
        
        word = (uint32_t)Bitpack_newu(word, 4, 28, opcode);
        word = (uint32_t)Bitpack_newu(word, 3, 25, ra);
        word = (uint32_t)Bitpack_newu(word, 25, 0, val);

        return word;

}

/*Tests loadval and output
    Creates instruction with loadval and output 
    instructions to load values into r1 and r2 and output the value of r3*/
void load_val_once_test(Seq_T stream) {

        append(stream, loadval(r1, 33));
        append(stream, output(r1));
        append(stream, halt());

}


/*high_add_test - 
    Tests add with high values 
    Creates instruction to load values into r2 (254) and r3 (0) at top of 
    32 bit range. Outputs r1 to ensure it is expected value (254). */
void high_add_test(Seq_T stream) {
        
        append(stream, loadval(r1, 6));
        append(stream, loadval(r2, 254));
        append(stream, loadval(r3, 0));
        append(stream, add(r1, r2, r3));
        append(stream, output(r1));
        append(stream, halt());
        
}


/*    Creates instruction to load values into r1 (5), r2 (100), and r3 (2) and 
    then execute divide instruction. Outputs r1 to ensure it is expected value
    (50). */
void divide_test(Seq_T stream) {
        append(stream, loadval(r1, 5));
        append(stream, loadval(r2, 100));
        append(stream, loadval(r3, 2));
        append(stream, div(r1, r2, r3));
        append(stream, output(r1));
        append(stream, halt());
}

/*  Tests divide instruction when division would result in a fraction 
    Creates instruction to load values into r1 (14), r2 (90), and r3 (7) and 
    then execute divide instruction. Output r1 to ensure it is expected value 
    (12).*/
void divide_frac_test(Seq_T stream) {
        append(stream, loadval(r1, 14));
        append(stream, loadval(r2, 90));
        append(stream, loadval(r3, 7));
        append(stream, div(r1, r2, r3));
        append(stream, output(r1));
        append(stream, halt());
}

/*    Test multiplication instruction on small values. 
    Creates instruction to load values into r1 (0), r2 (10), and r3 (5) and 
    then execute multiplication instruction. Output r1 to ensure it is expected 
    value (50).*/
void small_mult_test(Seq_T stream) {
        append(stream, loadval(r1, 0));
        append(stream, loadval(r2, 10));
        append(stream, loadval(r3, 5));
        append(stream, mul(r1, r2, r3));
        append(stream, output(r1));
        append(stream, halt());
}

/*  Tests multiplication instruction on large values 
    Creates instruction to load values into r1 (0), r2 (20), r3 (11) and then 
    execute multiplication instruction. Output r1 to ensure it is expected 
    value (220).*/
void big_mult_test(Seq_T stream) {
        append(stream, loadval(r1, 0));
        append(stream, loadval(r2, 20));
        append(stream, loadval(r3, 11));
        append(stream, mul(r1, r2, r3));
        append(stream, output(r1));
        append(stream, halt());
}

/*  Tests multiplication instruction and division instruction 
    Creates intruction to load values into r1 (5), r2 (13), r3 (215), and r4
    (255) and multiply r2 and r3 and store in r1 and divide r1 by r4. Output
    r1 to ensure it is expected value (10).*/
void big2_mult_test(Seq_T stream) {
        append(stream, loadval(r1, 5));
        append(stream, loadval(r2, 13));
        append(stream, loadval(r3, 215));
        append(stream, loadval(r4, 255));
        append(stream, mul(r1, r2, r3));
        append(stream, div(r1, r1, r4));
        append(stream, output(r1));
        append(stream, halt());
}

/*Tests multiplication 
    Creates instruction to load values into r1 (5), multiply by r1(5)and store 
    back into r1. Output r1 to make sure it is expected value (25).*/
void samereg_mult_test(Seq_T stream) {
        append(stream, loadval(r1, 5));
        append(stream, mul(r1, r1, r1));
        append(stream, output(r1));
        append(stream, halt());
}


/*  Tests bitwise and and negation function.
    Creates instruction to load r1 with 0 then NAND r1 with r1 and store in r3.
    Then, NAND r3 and r3 and store in r1. Then adds 1 to r1 and outputs r1 to 
    ensure it is expected value of 1. */
void bitwise_test(Seq_T stream){ 
        append(stream, loadval(r1, 0));
        append(stream, loadval(r2, 1));
        append(stream, nand(r3, r1, r1));
        append(stream, nand(r1, r3, r3));
        append(stream, add(r1, r2, r1));
        append(stream, output(r1));
        append(stream, halt());
}


/*    Tests conditional move on the case where rc = 0
    Creates an instruction that loads 0 into r3, 5 into r1, and 7 into r2
    (conditional move does not occur)
    Outputs the original register to ensure it is the expected value
    r1 = 5.*/
void condmv_0_test(Seq_T stream){ 
        append(stream, loadval(r1, 5));
        append(stream, loadval(r2, 7));
        append(stream, loadval(r3, 0));
        append(stream, cmov(r1, r2, r3));
        append(stream, output(r1));
        append(stream, halt());
}

/*  Tests conditional move on the non-zero case with small values
    Creates an instruction to load r1 = 5, r2 = 7, and r3 = 1 and output r1
    to ensure it is expected value of 7. */
void condmv_small_test(Seq_T stream){ 
        append(stream, loadval(r1, 5));
        append(stream, loadval(r2, 7));
        append(stream, loadval(r3, 1));
        append(stream, cmov(r1, r2, r3));
        append(stream, output(r1));
        append(stream, halt());
}

/* condmv_big_test
    Tests conditional move on the non-zero case with small values
    Creates an instruction to load r1 = 126, r2 = 245, and r3 = 89 and output 
    r1 to ensure it is expected value of 126.  */
void condmv_big_test(Seq_T stream){ 
        append(stream, loadval(r1, 126));
        append(stream, loadval(r2, 245));
        append(stream, loadval(r3, 89));
        append(stream, cmov(r1, r2, r3));
        append(stream, output(r1));
        append(stream, halt());
}

/* input1_test
    Tests input with a non-EOF character 
    Creates an instruction stream with input and loads into r1, then outputs r1.
    Expected input is ! and expected output is ! */
void input1_test(Seq_T stream) {
        append(stream, input(r1));
        append(stream, output(r1));
        append(stream, halt());
}

/* seg0_test
    Tests segment load and segment store 
    Creates instruction to load r1 with 2, r2 with 0, r3 with 0, and r4 with 4,
    then to store the value in r4 at segment 0 at 0, then to load the value at 
    0 0 into r1. Then output r1 to ensure it is expected value (4).*/
void seg0_test(Seq_T stream) {
        append(stream, loadval(r1, 3));
        append(stream, loadval(r2, 0));
        append(stream, loadval(r3, 0));
        append(stream, loadval(r4, 4));
        append(stream, sstore(r2, r2, r4));
        append(stream, sload(r1, r2, r2));
        append(stream, output(r1));
        append(stream, halt());
}

/* reg5_sload_test
    Tests segment load and map 
    Creates instruction that loads values r1 = 33, r2 = 0, r3 = 2 and r4 = 4, 
    then to map a new segment with the value of words in r3, then to perform
    sam sequence of instrctions as seg0_test in terms of segload and segstore, 
    but on newly mapped sequence. Output r4 to ensure it is the expected value 
    (33). */
void reg5_sload_test(Seq_T stream) {
        append(stream, loadval(r1, 33));
        append(stream, loadval(r2, 0));
        append(stream, loadval(r3, 2));
        append(stream, loadval(r4, 4));
        append(stream, map(r3, r3));
        append(stream, sstore(r3, r3, r1));
        append(stream, sload(r4, r3, r3));
        append(stream, output(r4));
        append(stream, halt());
}


/* Tests multiplication, map segment, loadprogram 0 case, addition, sstore, 
    sload. 
    Creates instruction stream to do the following: 
        Load r1 with 254 and square r1. Then load that value back in r1.
        Map segment with 254^2 words. 
        Duplicate segment 0 and store back at segment 0.
        Output each register 
        Load 254 in r1 and add with r3
        sstore m[0][254] in r3
        sload r2 in m[0][254] 
        adds 1 to r1 and outputs r1. */
void consec_arithmetic(Seq_T stream) { 
        
        append(stream, loadval(r1, 254));
        append(stream, loadval(r2, 0));
        append(stream, loadval(r3, 0));
        append(stream, mul(r2, r2, r1));
        append(stream, map(r2, r2));
        append(stream, loadval(r1, r1));
        append(stream, add(r1, r2, r3));
        append(stream, sstore(r3, r3, r1));
        append(stream, sload(r3, r3, r3));
        append(stream, loadval(r4, 1));
        append(stream, add(r3, r4, r3));
        append(stream, output(r3));
        append(stream, halt());
}


/* Tests loadval with high values
    Creates instruction stream to :
        load r1 with 0 and output
        load r2 with 33554431 and r3 with 1000000
        Divide r2 by r3
        output r1 to ensure it is expected output of 33*/
void loadval_low_high_tester(Seq_T stream) {
        append(stream, loadval(r1, 0));
        append(stream, loadval(r2, 33554431));
        append(stream, loadval(r3, 1000000));
        append(stream, div(r1, r2, r3));
        append(stream, output(r1));
        append(stream, halt());
}

/* Tests consecutive loadvals
    Creates instructions stream that loads back to back values into r3 and then
    outputs r3 to make sure it has been updated to 78. */
void mult_load(Seq_T stream) {
        append(stream, loadval(r3, 45));
        append(stream, loadval(r3, 28));
        append(stream, loadval(r3, 78));
        append(stream, output(r3));
        append(stream, halt());
}

 /* Tests end of output ranges 
    Creates instruction stream that loads r1 with value 0 and then outputs*
    then loads r1 with value 255 and outputs r1 again.
    *Because umlabwrite cannot write 0 to a file as ASCII and create a .1 file
    (reads output as null), we ommitted outputting 0 in submission, but used
    it for our actual testing. 
*/
void output_0_255(Seq_T stream) {
        append(stream, loadval(r1, 0));
        //append(stream, output(r1));
        append(stream, loadval(r1, 255));
        append(stream, output(r1));
        append(stream, halt());

}

 /*Tests map segment and unmap segment
    Creates an instruction stream that loads r1 with 3 and r2 with 4. 
    Then to map a segment with number of words in r1 and another with 
    number of words in r2. Then to unmap segment at r1, then to map another 
    segment with number of words in r1 with ID stored in R1. Output r1 to 
    ensure that mapped segment ID is expected value.
*/
void map_unmap(Seq_T stream) {
        append(stream, loadval(r1, 3));
        append(stream, loadval(r2, 4));
        append(stream, map(r1, r1));
        append(stream, map(r2, r2));
        append(stream, unmap(r1));
        append(stream, map(r1, r1));
        append(stream, output(r1));
        append(stream, halt());
}





