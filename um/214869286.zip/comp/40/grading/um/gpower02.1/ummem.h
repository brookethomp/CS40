/* ummem.h 
    Written by Georgia Power and Brooke Thompson for CS40 HW6: UM 

    Interface for the ummem module used by the UM. Defines functions for 
    UM instructions map segment, unmap segment, segment store, and segment 
    load as well as consructor and destructor for the UM_memory_structures 
    struct. 

*/
#ifndef UM_MEM
#define UM_MEM


#define UM_register uint32_t
#define UM_instruction uint32_t


struct UM_memory_structures;


struct UM_memory_structures* constructMemory();
void freeUM_mem(struct UM_memory_structures* memory);

void map_seg(UM_register* registers, struct UM_memory_structures* memory, 
                                            UM_register rc, UM_register rb);
void unmap_seg(UM_register* registers, struct UM_memory_structures* memory, 
                                                            UM_register rc);
void seg_store(UM_register* registers, struct UM_memory_structures* memory, 
                            UM_register ra, UM_register rb, UM_register rc);
void seg_load(UM_register* registers, struct UM_memory_structures* memory,
                             UM_register ra, UM_register rb, UM_register rc);




#endif