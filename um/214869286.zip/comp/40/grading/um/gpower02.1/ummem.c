/* ummem.c 
    Written by Georgia Power and Brooke Thompson for CS40 HW6: UM 

    Implementation for the ummem module. Implements functionality for UM 
    instructions map segment, unmap segment, segment store, and segment 
    load as well as consructor and destructor for the UM_memory_structures 
    struct. 

    The module relies on Hanson implementations of the sequence, UArray, and
    stack data structures to represent the mapped and unmapped memory of the 
	UM. 
	
    Course solutions for bitpack are also used to reference/ create information 
    stored in the form of UM instructions.

*/
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <seq.h>
#include <stack.h>
#include <bitpack.h>
#include <uarray.h>
#include "ummem.h"


typedef uint32_t UM_register;
typedef uint32_t UM_instruction;
typedef uint32_t Program_P;
typedef uint32_t Seg_ID;
#define REG_WIDTH 3
#define VALUE_WIDTH 25
#define WORD_SIZE 4



/***** struct UM_memory_structures *********/
/*  Packaged representation of UM's memory 
    member variables:   
        Seq_T holding mapped memory segments in the UM in the form of UArray_Ts
        Stack_T holding pointers to uint32_t IDs indicating segments that have 
        been unmapped.
*/
typedef struct UM_memory_structures { 
    	Seq_T mapped_memory; 
    	Stack_T unmapped_IDs;
} *UM_mem;



/* private declarations */
Seg_ID IDhelper(UM_mem memory);




/****** constructMemory *******
 * 
 *   Initializes UM_memory_structures struct and its members returned
 *   as a pointer to be used in the UM program
 * 
 *  Inputs: none
 *     
 *  Return: UM_memory_structures struct pointer
 *  Expects: none 
 *  Notes: will CRE if malloc, Seq_new, or Stack_new fail. 
 *          Memory allocated by this function is freed by freeUM_mem 
 *          at the end of the UM main. 
 ************************/
UM_mem constructMemory() 
{ 
    	struct UM_memory_structures* memory; 
    	memory = malloc(sizeof(struct UM_memory_structures));
    	assert (memory != NULL);

    	/* initialize sequence to hold mapped memory */
	int hint = 1000; 
    	memory->mapped_memory = Seq_new(hint);
   	assert (memory->mapped_memory != NULL);
    
	/* initialize stack to hold unmapped IDs */
    	memory->unmapped_IDs = Stack_new();
    	assert (memory->unmapped_IDs != NULL);

    	return memory; 

}





/****** map_seg *******
 * 
 *  Maps a segment with the number of words of the value in rc and places its
 *  ID in rb. Calls IDhelper() to determine where to place the segment. 
 * 
 *  Inputs: UM_registers* registers: array of uint32_ts representing the 
 *          UM's registers
 *          UM_mem pointer
 *          UM_registers rc and rb
 *     
 *  Return: None
 *  Expects: Passed UM_registers array not to be null, Passed UM_mem not to 
 *           be NULL. 
 *           
 *  Notes: Program terminates in CRE if expectations are not met. 
 ************************/
void map_seg(UM_register* registers, UM_mem memory, UM_register rc, 
                                                            UM_register rb) 
{
    
   	assert (registers != NULL);
   	assert (memory != NULL);
   
    	/* get size of new segment and allocate new array */
	uint32_t num_words = registers[rc];
    	UArray_T new_segment = UArray_new((int)num_words, sizeof(uint32_t));
    
    	/* initialize all values in segment to 0*/
	for (int i = 0; i < (int)num_words; i++) {
       		assert((uint32_t*)UArray_at(new_segment, i) != NULL);
       		*(uint32_t*)UArray_at(new_segment, i) = 0;
    	}


    	/* if we don't have an unmapped ID to use, add the segment to the 
	   top of the sequence and place the segment's ID in rb */
	if (Stack_empty(memory->unmapped_IDs)) {

        	Seq_addhi(memory->mapped_memory, new_segment); 
        	Seg_ID new_id = IDhelper(memory);
        	registers[rb] = new_id;
    	}
    
	/* if we do have an unmapped ID to use, place the segment at that 
	   index in the sequence. Check that there wasn't a segment already 
	   there and free it if there was */
    	else {
        
        	Seg_ID new_id = IDhelper(memory);
        	registers[rb] = new_id;
        	void* garbage = Seq_put(memory->mapped_memory, new_id, 
								new_segment);
        	UArray_T check = (UArray_T)garbage;
		if (check != NULL) {
            		UArray_free(&check);
        	}
        
    	}

}


/****** IDhelper *******
 * 
 *  Resturns a new ID for a mapped segment. Pops the unmapped_IDs stack if 
 *  it is not empty to reuse unmapped_IDs. Otherwise, sets ID to the length
 *  of the unmapped IDs sequence. 
 * 
 *  Inputs: UM_mem pointer to UM memory struct
 *     
 *  Return: Seg_ID: typedef'd uint32_t representing the segment ID
 *  Expects: Passed UM memory struct to not be NULL 
 *  Notes: Program will terminate in CRE if expectations are not met. 
 *		Pointer associated with unmapped memory ID, if reused, 
 *		 is freed when popped from the stack.
 *		
 ************************/
Seg_ID IDhelper(UM_mem memory)
{
    
    	assert (memory != NULL);
    
    	Seg_ID new_id; 

	/* if we don't have an available unmapped ID, set ID to the length 
	   of the mapped_memory sequence - 1  */
    	if (Stack_empty(memory->unmapped_IDs)) { 
        	new_id = (Seq_length(memory->mapped_memory)) - 1; 
    	}

   	/* if we do have an available unmapped ID, pop the stack, free the
	  popped pointer and return that value */
	else { 
        	Seg_ID *top_ID = (uint32_t*)Stack_pop(memory->unmapped_IDs);
        	new_id = *top_ID; 
        	free(top_ID);
    	}

    	return new_id;

}



/****** unmap_seg *******
 * 
 *  Unmaps a segment at the ID held in rc
 * 
 *  Inputs: UM_registers* registers representing the UM's registers 
 *		UM_mem pointer holding UM's memory to be accessed
 *		UM_register rc
 *     
 *  Return: none
 *  Expects: passed UM_registers array, UM_mem not to be NULL
 *  Notes: Program will terminate in CRE if expectations are not met
 *	Frees memory of the UArray_T holding segment being freed.
 *	Memory allocated for the pointer holding the new ID is freed either 
 *	when the ID is reused, or when the stack is freed by freeUM_mem at the 
 *	end of UM. 
 ************************/
void unmap_seg(UM_register* registers, UM_mem memory, UM_register rc) 
{
    
    	assert (registers != NULL);
    	assert (memory != NULL);
    
    	Seg_ID identifier = registers[rc];
    	UArray_T segment = Seq_get(memory->mapped_memory, identifier);
    	UArray_free(&segment);
    	
	/* place NULL value into index that was just freed so we can check 
	   for NULL when freeing the whole structure later */
	UArray_T garb = Seq_put(memory->mapped_memory, identifier, NULL);
    	(void)garb;

	/* make pointer holding unmapped ID and push it to the stack 
	   to be reused */
    	Seg_ID* id_p = malloc(sizeof(uint32_t)); 
    	assert (id_p != NULL);
    	*id_p = identifier;

    	Stack_push(memory->unmapped_IDs,id_p);
   
}




/****** seg_load *******
 * 
 *   Retrieves a value in memory at $m[$rb][$rc] and places it in ra
 * 
 *  Inputs: UM_registers* registers representing the UM's registers 
 *		UM_mem pointer holding UM's memory to be accessed
 *		UM_registers ra, rb rc
 *     
 *  Return: none
 *  Expects: passed UM_registers, UM_mem not to be NULL 
 *  Notes: Program will terminate in CRE if expectations are not met or 
 *	  if the accessed value in memory is NULL
 ************************/
void seg_load(UM_register* registers, UM_mem memory, UM_register ra, 
					UM_register rb, UM_register rc) 
{
    
    	assert (registers != NULL);
    	assert (memory != NULL);

    	UM_register bval = registers[rb];
    	UM_register cval = registers[rc];
    
	/* get value at $m[$rb][$rc] */
    	UArray_T segment = Seq_get(memory->mapped_memory, bval);
    	uint32_t *value = (uint32_t*)UArray_at(segment, cval); 
    	assert (value != NULL);
    	
	/* assign value to register a */
	registers[ra] = *value;

}




/****** seg_store *******
 * 
 *  Retrieves a address in memory at $m[$ra][$rb] and assigns it to 
 *  the value of rc
 * 
 *  Inputs: UM_registers* registers representing the UM's registers 
 *		UM_mem pointer holding UM's memory to be accessed
 *		UM_registers ra, rb rc
 *     
 *  Return: none
 *  Expects: passed UM_registers, UM_mem not to be NULL 
 *  Notes: Program will terminate in CRE if expectations are not met or 
 *	  if the accessed value in memory is NULL
 ************************/
void seg_store(UM_register* registers, UM_mem memory, UM_register ra, 
                                            UM_register rb, UM_register rc) 
{
    
    	assert(registers != NULL);
    	assert (memory != NULL);
    
    	UM_register aval = registers[ra];
    	UM_register bval = registers[rb];
    
	/* get address at $m[$ra][$rb] */
    	UArray_T segment = Seq_get(memory->mapped_memory, aval);
    	uint32_t *value = UArray_at(segment, bval); 
    	assert (value != NULL);
    	
	/* assign value to register c */
	*value = registers[rc];

}



/****** freeUM_mem *******
 * 
 *  Frees the memory associated with UM_memory_structures and its members
 * 
 *  Inputs: UM_mem: pointer to a UM_memory struct to be freed
 *     
 *  Return: none
 *  Expects: Passed UM_mem pointer to be NULL, member stack and sequence 
 *		not to be NULL 
 *  Notes: Program will terminate in CRE if expectations are not met.
 ************************/
void freeUM_mem(UM_mem memory) 
{ 
    	assert (memory != NULL);
    	assert(memory->unmapped_IDs != NULL);
    	assert(memory->mapped_memory != NULL);
    
    
    	/* free pointers held in stack and stack structure */
    	while (!(Stack_empty(memory->unmapped_IDs))) { 
        	Seg_ID *to_free = Stack_pop(memory->unmapped_IDs);
        	free(to_free); 
    	}

   	Stack_free(&memory->unmapped_IDs);

    
    	/* free mapped memory */
    	int memory_length = Seq_length(memory->mapped_memory);
    	for (int index = 0; index < memory_length; index++) { 
        	UArray_T segment = Seq_get(memory->mapped_memory, index); 
        	if (segment != NULL) { 
            		UArray_free(&segment);
        	}
    	}

    	Seq_free(&memory->mapped_memory);
	
	/* free struct pointer*/
    	free(memory);

}




