/* umarithmetic.c 
    Written by Georgia Power and Brooke Thompson for CS40 HW6: UM 

        
        Implementations for UM instructions load value, add, multiply, divide, 
        conditional move, input, output, and bitwise NAND used by 
        the UM program. Alters the registers of a UM passed by reference to 
        each function. 

        Note that every value stored will be implicitly modded by 2^32 since 
        UM registers are represented as uint32_ts. 

        Relies on CS40 course implementation of bitpack to implement
        bitwise NAND and to extract and store values from and 
        within UM instructions 
    
*/
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <assert.h>
#include <seq.h>
#include <string.h>
#include <stdlib.h>
#include <uarray.h>
#include <bitpack.h>



typedef uint32_t UM_register;
typedef uint32_t UM_instruction;
typedef uint32_t Reg_value;
#define REG_WIDTH 3
#define WORD_SIZE 4
#define LV_REG_LSB 25
#define VALUE_WIDTH 25
#define LV_VALUE_LSB 0
#define MAX 255
#define MIN 0

uint32_t getField(UM_instruction instruction, uint32_t width, uint32_t LSB);



/****** add *******
 * 
 *   Adds values in rb and rc and places sum in ra
 *   % 2^32 is implicit since the value is stored in a uint32_t
 * 
 *  Inputs: UM_registers* registers: array representing the UM's registers 
 *		    UM_registers ra, rb rc
 *     
 *  Return: none
 *  Expects: passed UM_registers pointer not to be NULL 
 *  Notes: Program will terminate in CRE if expectations are not met, 
            changes value in UM regsiters at ra.
 ************************/
void add(UM_register *registers, UM_register ra, UM_register rb, 
                                                            UM_register rc) 
{
        assert (registers != NULL);
        Reg_value value = (registers[rb] + registers[rc]);
        registers[ra] = value; 
}


/****** multiply *******
 * 
 *   Multiplies values in UM registers rb and rc and places product in ra. 
 *   % 2^32 is implicit since the value is stored in a uint32_t
 * 
 *  Inputs: UM_registers* registers: array representing the UM's registers 
 *		    UM_registers ra, rb rc
 *     
 *  Return: none
 *  Expects: passed UM_registers pointer not to be NULL 
 *  Notes: Program will terminate in CRE if expectations are not met, 
            changes value in UM registers at ra.
************************/
void multiply(UM_register *registers, UM_register ra, UM_register rb,
                                                             UM_register rc) 
{
    
        assert (registers != NULL);
        Reg_value value = (registers[rb] * registers[rc]); 
        registers[ra] = value;

}

/****** divide *******
 * 
 *   Divides value in UM register rb and by value rc and places quotient in ra. 
 * 
 *  Inputs: UM_registers* registers: array representing the UM's registers 
 *		    UM_registers ra, rb rc
 *     
 *  Return: none
 *  Expects: passed UM_registers pointer not to be NULL 
 *  Notes: Program will terminate in CRE if expectations are not met, 
            changes value in UM registers at ra.
************************/
void divide(UM_register *registers, UM_register ra, UM_register rb, 
                                                                UM_register rc) 
{
   
        assert (registers != NULL);
        Reg_value value =  (registers[rb] / registers[rc]);
        registers[ra] = value;
}


/****** bitwiseNAND *******
 * 
 *   Bitwise ands the values in UM_registers rb and rc, and negates the result.
 *   Places this value into UM_register ra 
 * 
 *  Inputs: UM_registers* registers: array representing the UM's registers 
 *		    UM_registers ra, rb rc
 *     
 *  Return: none
 *  Expects: passed UM_registers pointer not to be NULL 
 *  Notes: Program will terminate in CRE if expectations are not met, 
            changes value in UM registers at ra.
************************/
void bitwiseNAND(UM_register *registers, UM_register ra, UM_register rb,
                                                             UM_register rc) 
{
        assert (registers != NULL);
        Reg_value value = registers[rb] & registers[rc];
        registers[ra] = ~value;
}



/****** conditional_move *******
 * 
 *   Moves the value in UM_register rb into UM_register ra if the value in 
 *  UM_register rc is not 0. 
 * 
 *  Inputs: UM_registers* registers: array representing the UM's registers 
 *		    UM_registers ra, rb rc
 *     
 *  Return: none
 *  Expects: passed UM_registers pointer not to be NULL 
 *  Notes: Program will terminate in CRE if expectations are not met, 
            changes value in UM registers at ra.
************************/
void conditional_move(UM_register *registers, UM_register ra, 
                                            UM_register rb, UM_register rc) {
   
        assert (registers != NULL);
   
        if (registers[rc] != 0) {
            registers[ra] = registers[rb];
        }

}

/****** input *******
 * 
 *   Waits for stdin input and places value into rc. If no input is given,
 *   UM_register rc is set to a 32 bit word of all ones.  
 *       
 * 
 *  Inputs: UM_registers* registers: array representing the UM's registers 
 *		    UM_register rc
 *          FILE* representing stdin 
 *     
 *  Return: none
 *  Expects: passed UM_registers pointer not to be NULL, value from STD in 
 *          to be between 0 and 255
 *         
 *  Notes: Program will terminate in CRE if expectations are not met, 
            changes value in UM registers at rc.
************************/
void input(UM_register *registers, UM_register rc, FILE*input)
{
        assert (registers!= NULL);

        int value; 
        value = fgetc(input);
        assert (value <= MAX);

        /* if value is EOF, set rc to ~0 */
        if (value == EOF) { 
            UM_instruction allones = ~0;
            registers[rc] = allones;
            return;
        }

        /* otherwise set to the value */
        registers[rc] = (Reg_value)value;
    
}

/****** output_val *******
 * 
 *  Outputs value in UM_register rc to stdout
 * 
 *  Inputs: UM_registers* registers: array representing the UM's registers 
 *		    UM_register rc
 *     
 *  Return: none
 *  Expects: passed UM_registers pointer not to be NULL, value being outputted
 *          to be between 0 and 255
 *         
 *  Notes: Program will terminate in CRE if expectations are not met.
************************/
void output_val(UM_register *registers, UM_register rc) 
{ 
        assert(registers != NULL);

        Reg_value value = registers[rc];
        assert (value <= MAX);
        fputc(value, stdout);

}



/****** load_val *******
 * 
 *  Extracts ra and a 25 bit value from an instruction and loads a 25 bit 
 *  value into ra
 * 
 *  Inputs: UM_registers* registers: array representing the UM's registers 
 *		    UM_instruction instruction: word from which ra and 25 bit 
 *                  value are extracted 
 *     
 *  Return: none
 *  Expects: passed UM_registers pointer not to be NULL
 *         
 *  Notes: Program will terminate in CRE if expectations are not met, 
            changes value in UM registers at ra.
************************/
void load_value(UM_instruction instruction, UM_register* registers) {
    
        assert (registers != NULL);
    
        UM_register ra = getField (instruction, REG_WIDTH, LV_REG_LSB);
        Reg_value value = getField (instruction, VALUE_WIDTH, LV_VALUE_LSB);    

        registers[ra] = value;

}

/****** get_field *******
 * 
 *  Extracts a bit value from an instruction
 * 
 *  Inputs: 
 *		    UM_instruction instruction: word from which values
 *          are extracted 
 *          uint32_t denoting width of field 
 *          uint32_t denoting LSB of field 
 *     
 *  Return: uint32_t representing extracted field 
************************/
uint32_t getField(UM_instruction instruction, uint32_t width, uint32_t LSB)
{
        return Bitpack_getu((uint64_t)instruction, width, LSB);
}